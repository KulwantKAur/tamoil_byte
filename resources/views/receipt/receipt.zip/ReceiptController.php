<?php

namespace App\Http\Controllers;

use \BillbeeDe\BillbeeAPI\Client;
use \App\Product;
use Illuminate\Http\Request;
use BillbeeDe\BillbeeAPI\Model\Stock;
use Mail;
use BillbeeDe\BillbeeAPI\Model\StockCode;
use DB;

class ReceiptController extends Controller {

    private $billbee;
    private $client;

    public function __construct(Request $request) {
        $this->billbee = \config('billbee');
        $this->client = new Client($this->billbee['username'], $this->billbee['password'], $this->billbee['api_key']);
        parent::__construct($request);
    }

    public function inbound() {
        return view('receipt.inbound');
    }

    public function index() {
        return view('receipt.index');
    } // | index
	
	public function b2creturn() {
        return view('receipt.b2creturn');
    } 
	
	public function b2breturn() {
        return view('receipt.b2breturn');
    } 

	public function wareneingang() {
        return view('receipt.wareneingang');
    } 

	public function umbuchen() {
        return view('receipt.umbuchen');
    } 


    public function getProductByEan($ean = NULL) {
        $product = Product::where("ean", $ean)->first();
		$pro = $product->toArray();
		$pro['a_ware'] = '171';
		$pro['b_ware'] = '226';
		$pro['b2b'] = '265';
		$pro['defekt'] = '999';
		$pro['reason_code'] = array('Gefaellt-nicht','Defekt','Sonsitges');
        return json_encode($product ? $pro : []);
    } // | getProductByEan

    public function updateProductStockCode(Request $request) {
		set_time_limit(1000);
		$requestData = $request->all();
		$reason = $requestData["reason"];
		$Comment = $requestData['comment'] ;

        $stockModels = [];
		$StockDB = [];
		/*if it is a 
			B2C  - reason 1- or 
			B2B - reason 2 - or
			New Delivery - reason 3
		show the complete "book to stock ID" set: */
		if(($reason == '1')|| ($reason == '2')|| ($reason == '3')){
			foreach($requestData['receipt_booking'] as $key => $data) {
				$product = $this->client->getProduct($data["billbe_id"]);
				//dd($data);
				// | For A-ware
				$stockModel = Stock::fromProduct($product->data);
				$stockModel->setStockId($data['a_ware']['stockid']);
				$stockModel->setNewQuantity($this->getStockCurrent($product->data->stocks, $data['a_ware']['stockid']) + $data['a_ware']['quantity']);
				$stockModel->setReason($requestData["refrence"]);
				$stockModels[] = $stockModel;
				$data['a_ware']['stock_current'] = $this->getStockCurrent($product->data->stocks, $data['a_ware']['stockid']) + $data['a_ware']['quantity'];

				// | For B-ware
				$stockModel_2 = Stock::fromProduct($product->data);
				$stockModel_2->setStockId($data['b_ware']['stockid']);
				$stockModel_2->setNewQuantity($this->getStockCurrent($product->data->stocks, $data['b_ware']['stockid']) + $data['b_ware']['quantity']);
				$stockModel_2->setReason($requestData["refrence"]);
				$stockModels[] = $stockModel_2;

				$data['b_ware']['stock_current'] = $this->getStockCurrent($product->data->stocks, $data['b_ware']['stockid']) + $data['b_ware']['quantity'];
				
				if ($reason == '3'){
				// | For B2B
					$stockModel_3 = Stock::fromProduct($product->data);
					$stockModel_3->setStockId($data['b2b']['stockid']);
					$stockModel_3->setNewQuantity($this->getStockCurrent($product->data->stocks, $data['b2b']['stockid']) + $data['b2b']['quantity']);
					$stockModel_3->setReason($requestData["refrence"]);
					$stockModels[] = $stockModel_3;

					$data['b2b']['stock_current'] = $this->getStockCurrent($product->data->stocks, $data['b2b']['stockid']) + $data['b2b']['quantity'];												
				}
			}
			$stock = $this->client->updateStockMultiple($stockModels);
		}/*else if($reason == "3"){
			foreach($requestData['receipt_booking'] as $key => $data) {
				$product = $this->client->getProduct($data["billbe_id"]); 

				$stockModel = Stock::fromProduct($product->data);
				$stockModel->setStockId($this->billbee["stock_id"]);
				$stockModel->setNewQuantity($this->getStockCurrent($product->data->stocks, $this->billbee["stock_id"]) + $data["delta_quantity"]["quantity"]);
				$stockModel->setReason($requestData["refrence"]);
				$stockModels[] = $stockModel;
				
				// | For Delta-quantity
				$data['delta_quantity']['stockid'] = $this->billbee["stock_id"];
				$data['delta_quantity']['stock_current'] = $this->getStockCurrent($product->data->stocks, $this->billbee["stock_id"]) + $data["delta_quantity"]["quantity"];
			}
			$stock = $this->client->updateStockMultiple($stockModels);
		}*/
		//Book stock from stock ID A to stock ID B
		else if($reason == "4"){
			
			//take stock FROM
			if($requestData["StockId_up"]){
				foreach($requestData['receipt_booking'] as $key => $data) {
					$product = $this->client->getProduct($data["billbe_id"]);

					$stockModel = Stock::fromProduct($product->data);
					$stockModel->setStockId($requestData["StockId_up"]);
					$stockModel->setNewQuantity($this->getStockCurrent($product->data->stocks, $requestData["StockId_up"]) - $data["delta_quantity"]["quantity"]);
					$stockModel->setReason($requestData["refrence"]);
					$stockModels[] = $stockModel;

					// | For Delta-quantity
					$data['delta_quantity']['stockid'] = $requestData["StockId_up"];
					$data['delta_quantity']['stock_current'] = $this->getStockCurrent($product->data->stocks, $requestData["StockId_up"]) - $data["delta_quantity"]["quantity"];
				}
				$stock = $this->client->updateStockMultiple($stockModels);
			}
			//add stock TO
			if($requestData["StockId_down"]){
				foreach($requestData['receipt_booking'] as $key => $data) {
					$product = $this->client->getProduct($data["billbe_id"]);

					$stockModel = Stock::fromProduct($product->data);
					$stockModel->setStockId($requestData["StockId_down"]);
					$stockModel->setNewQuantity($this->getStockCurrent($product->data->stocks, $requestData["StockId_down"]) + $data["delta_quantity"]["quantity"]);
					$stockModel->setReason($requestData["refrence"]);
					$stockModels[] = $stockModel;
				}
				$stock = $this->client->updateStockMultiple($stockModels);
			}
		}
		
		//Prepare Data for sending a Mail to CUstomer SUpport
		if(($reason == '1') || ($reason == '2')){
			$ean_number = $requestData['pro_ean'];
			$pro_detail['pro_detail'] = [];
			$pro_detail['Referen'] = $requestData["refrence"] ? $requestData["refrence"] : '';

			foreach($requestData['receipt_booking'] as $value){
				$product = Product::where("ean", $value['ean'])->first();
				$product = $product->toArray();
				$result = array(
					'ean' => $product['ean'],
					'sku' => $product['sku'],
					'title' => $product['title'],
					'comment' => $Comment,
					'stock_current' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['a_ware']['stock_current'] : $value['delta_quantity']['stock_current'], 
					'delta_quantity' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['a_ware']['quantity'] : $value['delta_quantity']['quantity'],
					'stock_current_bware' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['b_ware']['stock_current'] : $value['delta_quantity']['stock_current'], 
					'delta_quantity_bware' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['b_ware']['quantity'] : $value['delta_quantity']['quantity'],
					'stock_current_defekt' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['defekt']['stock_current'] : $value['delta_quantity']['stock_current'], 
					'delta_quantity_defekt' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['defekt']['quantity'] : $value['delta_quantity']['quantity'],
					//'stock_current_b2b' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['b2b']['stock_current'] : $value['delta_quantity']['stock_current'], 
					//'delta_quantity_b2b' => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['b2b']['quantity'] : $value['delta_quantity']['quantity'],
				);
				$pro_detail['pro_detail'][] = $result;
			}
			
			if($reason == '1'){
				Mail::send('mail_templates.ean_detail', $pro_detail, function($message) use($pro_detail) {
					$message->to('christian@kerbholz.com')->subject(' Retoure - '.$pro_detail['Referen']); 
					//$message->to('saskia@onomao.com')->subject('B2C Retoure - '.$pro_detail['Referen']); 
				});
			}elseif($reason == '2'){
				Mail::send('mail_templates.ean_detail', $pro_detail, function($message) use($pro_detail) {
					$message->to('christian@kerbholz.com')->subject('B2B Retoure - '.$pro_detail['Referen']); 
					//$message->to('ophelia@onomao.com')->subject('B2B Retoure - '.$pro_detail['Referen']); 
				});				
			}
		}if($reason == '4'){
			$ean_number = $requestData['pro_ean'];
			$pro_detail['pro_detail'] = [];
			$pro_detail['Referen'] = $requestData["refrence"] ? $requestData["refrence"] : '';

			foreach($requestData['receipt_booking'] as $value){
				$product = Product::where("ean", $value['ean'])->first();
				$product = $product->toArray();
				$result = array(
					'ean' => $product['ean'],
					'sku' => $product['sku'],
					'title' => $product['title'],
					'comment' => $Comment,
					'stock_current' =>  $value['delta_quantity']['stock_current'], 
					'delta_quantity' => $value['delta_quantity']['quantity'],
					'stock_current_bware' => $value['delta_quantity']['stock_current'], 
					'delta_quantity_bware' => $value['delta_quantity']['quantity'],
					'stock_current_defekt' => $value['delta_quantity']['stock_current'], 
					'delta_quantity_defekt' => $value['delta_quantity']['quantity'],
					'stock_current_b2b' => $value['delta_quantity']['stock_current'], 
					'delta_quantity_b2b' => $value['delta_quantity']['quantity'],
				);
				$pro_detail['pro_detail'][] = $result;
			}
		}if($reason == '3'){
			$ean_number = $requestData['pro_ean'];
			$pro_detail['pro_detail'] = [];
			$pro_detail['Referen'] = $requestData["refrence"] ? $requestData["refrence"] : '';

			foreach($requestData['receipt_booking'] as $value){
				$product = Product::where("ean", $value['ean'])->first();
				$product = $product->toArray();
				$result = array(
					'ean' => $product['ean'],
					'sku' => $product['sku'],
					'title' => $product['title'],
					'comment' => $Comment,
					'stock_current' =>  $value['a_ware']['stock_current'] , 
					'delta_quantity' =>  $value['a_ware']['quantity'],
					'stock_current_bware' => $value['b_ware']['stock_current'], 
					'delta_quantity_bware' => $value['b_ware']['quantity'] ,
					'stock_current_defekt' => $value['defekt']['stock_current'] , 
					'delta_quantity_defekt' => $value['defekt']['quantity'],
					'stock_current_b2b' => $value['b2b']['stock_current'], 
					'delta_quantity_b2b' =>  $value['b2b']['quantity'],
				);
				$pro_detail['pro_detail'][] = $result;
			}
		}

		//summ all data to add into DB table
		$receipt_booking = [];
		foreach ($requestData['receipt_booking'] as $key => $value) {
			$receipt_booking[] = array(
				"receipt_type" => $value['receipt_type'],
				"reference" => $value['reference'],
				"ean" => $value['ean'],
				"reason_code" => ($reason == '1' || $reason == '2' ) ? $value['reason_code'] : null,
				"delta_quantity" => ($reason == '1') ? null : $value['delta_quantity']['quantity'],
				"stock_id" => null,
				"a_ware" => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['a_ware']['quantity'] : null,
				"b_ware" => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['b_ware']['quantity'] : null,
				"defekt" => ($reason == '1' || $reason == '2' || $reason == '3') ? $value['defekt']['quantity'] : null,
				"b2b" => ($reason == '3' || $reason == '4') ? $value['b2b']['quantity'] : null,
			);
		}
		DB::table("receipt_booking")->insert($receipt_booking);
        return response()->json(["success" => true]);
    }

    private function getStockCurrent($stocks = [], $stock_id) {
        $key = array_search($stock_id, array_column($stocks, 'StockId'));
        return $key === false ? 0 : $stocks[$key]["StockCurrent"];
	} // | getStockCode

}