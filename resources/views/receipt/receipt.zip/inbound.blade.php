@extends('layouts.app')

@section('title', 'Inbound')

@section('content')
    <div class="main-container pt-10 pb-10">
        <div class="flex-between mb-10">
            <button class="grey-btn btn">
                <a href="/b2creturn" onclick="disableParentButton(event)">
                    <span class="bold-text">B2C Return</span>
                </a>
            </button>
            <button class="grey-btn btn">
                <a href="/b2breturn" onclick="disableParentButton(event)">
                    <span class="bold-text">B2B Return</span>
                </a>
            </button>
            <button class="grey-btn btn">
                <a href="/umbuchen" onclick="disableParentButton(event)">
                    <span class="bold-text">Umbuchen</span>
                </a>
            </button>
			<button class="grey-btn btn">
                <a href="/wareneingang" onclick="disableParentButton(event)">
                    <span class="bold-text">Wareneingang</span>
                </a>
            </button>
        </div>
    </div>
@endsection